import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class HeaderService {
  http_1 = require('@angular/common/http');
  constructor(private httpclient: HttpClient) {}

  getheaderLinks(): Observable<any> {
    const AIP_URL = 'https://author-pall-stage.pall.com/bin/pall/links.json';
    var httpOptions = {
      headers: new this.http_1.HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
      }),
    };
    return this.httpclient.get(AIP_URL, httpOptions);
  }
  getMegamenu(): Observable<any> {
    const AIP_URL = 'https://author-pall-stage.pall.com/bin/pall/navigation.json';
    var httpOptions = {
      headers: new this.http_1.HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
      }),
    };
    return this.httpclient.get(AIP_URL, httpOptions);
  }
}
