import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsMegamenuComponent } from './products-megamenu.component';

describe('ProductsMegamenuComponent', () => {
  let component: ProductsMegamenuComponent;
  let fixture: ComponentFixture<ProductsMegamenuComponent>;
  let element: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductsMegamenuComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsMegamenuComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
    expect(element).toBeTruthy();
    expect(() => fixture.detectChanges()).not.toThrow();
  });
});
