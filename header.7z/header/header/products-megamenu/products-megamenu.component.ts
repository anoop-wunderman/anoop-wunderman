import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'ish-products-megamenu',
  templateUrl: './products-megamenu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductsMegamenuComponent {}
