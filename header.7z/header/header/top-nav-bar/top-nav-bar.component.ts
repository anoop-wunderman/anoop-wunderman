import { ChangeDetectionStrategy, Component } from '@angular/core';
import { faAngleDown, faChevronRight, faTimes } from '@fortawesome/free-solid-svg-icons';
import { Event, NavigationStart, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AppFacade } from 'ish-core/facades/app.facade';
import { DeviceType } from 'ish-core/models/viewtype/viewtype.types';
@Component({
  selector: 'ish-top-nav-bar',
  templateUrl: './top-nav-bar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopNavBarComponent {
  faAngleDown = faAngleDown;
  faChevronRight = faChevronRight;
  faTimes = faTimes;
  headerType$: Observable<string>;
  deviceType$: Observable<DeviceType>;
  isSticky$: Observable<boolean>;
  reset$: Observable<Event>;
  isShow = false;
  public show: boolean = false;
  public menuData;
  public data: any = [];
  constructor(private appFacade: AppFacade, private router: Router) {}

  ngOnInit() {
    this.headerType$ = this.appFacade.headerType$;
    this.deviceType$ = this.appFacade.deviceType$;
    this.isSticky$ = this.appFacade.stickyHeader$;
    this.reset$ = this.router.events.pipe(filter(event => event instanceof NavigationStart));
  }
  megaMenuApplications() {
    this.show = true;
    this.getDataApplication();
    // this.isShow = !this.isShow;

    // this.header.getMegamenu().subscribe(res => {
    //   this.data = res.industries;
    //   console.log(this.data, '-----------------');
    // });
    console.log('megaMenuApplications');
  }
  closeApplicaton() {
    this.show = false;
  }
  getDataApplication() {
    const myData = JSON.parse(localStorage.getItem('pall-megamenu'));
    this.data = myData.industries;
    console.log(this.data);
  }
  megaMenuProducts() {
    console.log('megaMenuProducts');
  }
}
