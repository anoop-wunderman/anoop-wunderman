import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopNavServiceBarComponent } from './top-nav-service-bar.component';

describe('TopNavServiceBarComponent', () => {
  let component: TopNavServiceBarComponent;
  let fixture: ComponentFixture<TopNavServiceBarComponent>;
  let element: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TopNavServiceBarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TopNavServiceBarComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
    expect(element).toBeTruthy();
    expect(() => fixture.detectChanges()).not.toThrow();
  });
});
