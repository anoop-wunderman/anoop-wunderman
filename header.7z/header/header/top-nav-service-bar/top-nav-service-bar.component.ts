import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { HeaderService } from '../../../../core/services/header/header.service';
@Component({
  selector: 'ish-top-nav-service-bar',
  templateUrl: './top-nav-service-bar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopNavServiceBarComponent implements OnInit {
  public data: any = [];
  constructor(private header: HeaderService) {
    if (localStorage.getItem('pall-smenu') == null && localStorage.getItem('pall-megamenu') == null) {
      this.header.getheaderLinks().subscribe(res => {
        localStorage.setItem('pall-smenu', JSON.stringify(res));
      });
      this.header.getMegamenu().subscribe(res => {
        localStorage.setItem('pall-megamenu', JSON.stringify(res));
      });
    }
  }
  getData() {
    const myData = JSON.parse(localStorage.getItem('pall-smenu'));
    this.data = myData.headerLinks;
    console.log(this.data);
  }
  ngOnInit() {
    this.getData();
  }
}
