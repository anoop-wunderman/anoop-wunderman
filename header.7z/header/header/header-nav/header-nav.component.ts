import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'ish-header-nav',
  templateUrl: './header-nav.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderNavComponent {}
