import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { faChevronRight, faTimes } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'ish-application-megamenu',
  templateUrl: './application-megamenu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ApplicationMegamenuComponent {
  faChevronRight = faChevronRight;
  faTimes = faTimes;
  @Input() isShow;

  toggleMenu() {
    this.isShow = !this.isShow;
  }
}
