import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'ish-header-checkout',
  templateUrl: './header-checkout.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderCheckoutComponent {}
